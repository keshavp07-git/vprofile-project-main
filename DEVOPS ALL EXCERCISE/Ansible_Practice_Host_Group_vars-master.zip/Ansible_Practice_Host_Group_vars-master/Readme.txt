--------------------------------------------------------------------------------------------------------------------------------------------------
TO ASSIGN VARIABLES FOR ALL HOST

# precedence.yaml created with no vairables for all host basically we comment them if we dont comment or remove in playbook variables 
have high precedence so it will take that variable.
# In precedence.yaml directory create another directory name group_vars
# In that folder create group_vars/all with vim , it will create all.yaml
# In that file just mention the variables like 
e.g.----
username: commonuser
comment: variable from groupvars for all.yaml named file for all host
# Then run with :-  ansible-playbook -i inventory.yaml precedence.yaml
# group_vars/all --- creating file this step it mean it will work for all hosts web01 , web02 , db01 
--------------------------------------------------------------------------------------------------------------------------------------------------
TO ASSIGN VARIABLES FOR PARTICULAR GROUP

# if we want to create vairables only for group like webserver or dbserver
# we have to create file as group name and we use vim group_vars/webserver
# In that file just mention the variables like 
e.g.----
username: webserver
comment: variable from groupvars for webserver.yaml named file for only webserver group

----------------------------------------------------------------------------------------------------------------------------------------------------
TO ASSIGN VARIABLES ANY PARTICULAR HOST 

# if we want to create vairables only for host like web01 or web02
# we have to create a folder host_vars
# In that folder we have to create file for host by using host_vars/web02
# After just assign values
e.g.----
username: web02
comment: variable from hostvars for web02.yaml named file for only host named web02

NOTE :- WE HAVE DIFFERENT TYPE OF METHOD TO ASSIGNING VARIABLES , WE CAN OVERRIDE THE PLAYBOOK VARIABLES VALUES BY USING ,
        ansible-playbook -i inventory.yaml -e username=cli -e comment=cli precedence.yaml -- HIGHEST PRIORITY THAN PLAYBOOK VARIABLES
        WE CAN ALSO FETCH VARIABLES FILE FROM OTHER LOCATION USING , 
        var_files:
            file/location/var.yaml -- HIGHEST PRIORITY BECAUSE IT IS FECTHING IN PLAYBOOK SO IT IS CONSIDERED AS PLAYBOOK VARIABLES