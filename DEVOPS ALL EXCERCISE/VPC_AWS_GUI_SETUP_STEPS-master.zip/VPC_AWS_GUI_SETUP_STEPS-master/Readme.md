# Steps to Create a VPC Using AWS Console

1. **Sign in to AWS Console**
    - Go to [https://console.aws.amazon.com/](https://console.aws.amazon.com/) and log in.

2. **Navigate to VPC Dashboard**
    - In the AWS Management Console, search for and select **VPC**.

3. **Start VPC Creation**
    - Click on **Your VPCs** in the left sidebar.
    - Click the **Create VPC** button.

4. **Configure VPC Settings**
    - Enter a **Name tag** for your VPC.
    - Specify an **IPv4 CIDR block** (e.g., `172.20.0.0/16`).
    - (Optional) Add an **IPv6 CIDR block**.
    - Choose **Tenancy** (default or dedicated).

5. **Create the VPC**
    - Review your settings.
    - Click **Create VPC**.

6. **Verify VPC Creation**
    - After creation, your new VPC will appear in the VPC list.


    ## Steps to Create 4 Subnets in 2 Availability Zones

    7. **Navigate to Subnets Section**
        - In the VPC Dashboard, click on **Subnets** in the left sidebar.

    8. **Create Subnets**
        - Click the **Create subnet** button.
        - Select your newly created VPC.

    9. **Configure Subnet Details**
        - For each subnet, provide a **Name tag** (e.g., `Subnet-A1`, `Subnet-A2`, `Subnet-B1`, `Subnet-B2`).
        - Choose two different **Availability Zones** (e.g., `us-east-1a` and `us-east-1b`).
        - Assign appropriate **IPv4 CIDR blocks** for each subnet (e.g., `172.20.1.0/24`, `172.20.2.0/24`, `172.20.3.0/24`, `172.20.4.0/24`). Assign two subnets to each availability zone.

    10. **Create the Subnets**
        - Review the configuration for each subnet.
        - Click **Create subnet** to finish.

    ## Steps to Create and Attach an Internet Gateway

    11. **Navigate to Internet Gateways**
        - In the VPC Dashboard, click on **Internet Gateways** in the left sidebar.

    12. **Create an Internet Gateway**
        - Click the **Create internet gateway** button.
        - Enter a **Name tag** for the gateway.
        - Click **Create internet gateway**.

    13. **Attach Internet Gateway to VPC**
        - Select the newly created internet gateway from the list.
        - Click **Actions** and choose **Attach to VPC**.
        - Select your VPC and click **Attach internet gateway**.

    ## Steps to Create a Route Table and Make Subnets Public

    14. **Navigate to Route Tables**
        - In the VPC Dashboard, click on **Route Tables** in the left sidebar.

    15. **Create a Route Table**
        - Click the **Create route table** button.
        - Enter a **Name tag** and select your VPC.
        - Click **Create route table**.

    16. **Add a Route to the Internet Gateway**
        - Select your new route table.
        - Go to the **Routes** tab and click **Edit routes**.
        - Click **Add route**.
        - For **Destination**, enter `0.0.0.0/0`.
        - For **Target**, select your Internet Gateway.
        - Click **Save changes**.

    17. **Associate Subnets with the Route Table**
        - Go to the **Subnet associations** tab of your route table.
        - Click **Edit subnet associations**.
        - Select the subnets you want to make public (e.g., `Subnet-A1`, `Subnet-B1`).
        - Click **Save associations**.

    18. **Enable Auto-Assign Public IP for Public Subnets**
        - Go to **Subnets** in the VPC Dashboard.
        - Select each public subnet.
        - Click **Actions** > **Edit subnet settings**.
        - Enable **Auto-assign public IPv4 address**.
        - Click **Save**.

    ## Steps to Create a NAT Gateway for Private Subnets

    19. **Create an Elastic IP Address**
        - In the VPC Dashboard, click on **Elastic IPs** in the left sidebar.
        - Click **Allocate Elastic IP address**.
        - Click **Allocate** and note the new Elastic IP.

    20. **Create a NAT Gateway**
        - Go to **NAT Gateways** in the VPC Dashboard.
        - Click **Create NAT gateway**.
        - Select a public subnet (e.g., `Subnet-A1` or `Subnet-B1`).
        - Assign the Elastic IP you created.
        - Click **Create NAT gateway**.

    21. **Create a Route Table for Private Subnets**
        - Go to **Route Tables** in the VPC Dashboard.
        - Click **Create route table**.
        - Enter a **Name tag** (e.g., `Private-Route-Table`) and select your VPC.
        - Click **Create route table**.

    22. **Add a Route to the NAT Gateway**
        - Select your new private route table.
        - Go to the **Routes** tab and click **Edit routes**.
        - Click **Add route**.
        - For **Destination**, enter `0.0.0.0/0`.
        - For **Target**, select your NAT Gateway.
        - Click **Save changes**.

    23. **Associate Private Subnets with the Private Route Table**
        - Go to the **Subnet associations** tab of your private route table.
        - Click **Edit subnet associations**.
        - Select the private subnets (e.g., `Subnet-A2`, `Subnet-B2`).
        - Click **Save associations**.

    ## Enable DNS Hostnames for the VPC

    24. **Enable DNS Hostnames**
        - In the VPC Dashboard, click **Your VPCs**.
        - Select your VPC.
        - Click **Actions** > **Edit VPC settings**.
        - Set **DNS hostnames** to **Enable**.
        - Click **Save changes**.


    ## Steps to Create a Bastion Host for Private Instances

    25. **Create a Key Pair**
        - In the EC2 Dashboard, click on **Key Pairs** in the left sidebar.
        - Click **Create key pair**.
        - Enter a name (e.g., `bastion-key`) and select **RSA** or **ED25519**.
        - Download and securely store the private key file.

    26. **Create a Security Group for the Bastion Host**
        - Go to **Security Groups** in the VPC Dashboard.
        - Click **Create security group**.
        - Enter a name (e.g., `bastion-sg`) and select your VPC.
        - Add an **inbound rule** to allow SSH (port 22) from your trusted IP address (e.g., your office or home IP).
        - Add an **outbound rule** to allow all traffic (default).
        - Click **Create security group**.

    27. **Launch the Bastion Host Instance**
        - Go to the **EC2 Dashboard** and click **Launch Instance**.
        - Choose an **Ubuntu** AMI (e.g., Ubuntu Server 22.04 LTS).
        - Select an **instance type** (e.g., t2.micro).
        - Choose the public subnet (e.g., `Subnet-A1` or `Subnet-B1`).
        - Attach the **bastion-sg** security group.
        - Select the **bastion-key** key pair.
        - Click **Launch Instance**.

    28. **Configure Security for Private Instances**
        - For each private instance, ensure its security group allows SSH (port 22) **only from the bastion host's security group** (use the security group ID as the source).
        - This restricts SSH access to private instances via the bastion host only.

    29. **Connect to Private Instances via Bastion Host**
        - SSH into the bastion host using the downloaded key:
          ```sh
          ssh -i /path/to/bastion-key.pem ubuntu@<bastion-public-ip>
          ```
        - From the bastion host, SSH into private instances using their private IP addresses.

        ## Steps to Create a Key Pair for Private Instance Access and Copy to Bastion Host

        30. **Generate a New SSH Key Pair Locally**
            - On your local machine, run:
              ```sh
              ssh-keygen -t rsa -b 4096 -f private-instance-key
              ```
            - This creates `private-instance-key` (private key) and `private-instance-key.pub` (public key).

        31. **Copy the Private Key to the Bastion Host**
            - Use `scp` to securely copy the private key to the bastion host's home directory:
              ```sh
              scp -i /path/to/bastion-key.pem private-instance-key ubuntu@<bastion-public-ip>:~
              ```
            - On the bastion host, set proper permissions:
              ```sh
              chmod 400 web-key.pem
              ```
            -- 
            scp -i Downloads/Bastion-Host-Key.pem Downloads/web-key.pem ubuntu@18.144.37.121:/home/ubuntu/ 
            -- Proper syntax for copying the key to the bastion host
        


        32. **Use the Key from the Bastion Host to Access Private Instances** (Optional)
            - SSH from the bastion host to a private instance:
              ```sh
              ssh -i ~/private-instance-key ubuntu@<private-instance-ip>
              ```
    ## Steps to Launch a Private Instance in a Private Subnet

    33. **Create a Security Group for Private Instances**
        - In the VPC Dashboard, go to **Security Groups**.
        - Click **Create security group**.
        - Enter a name (e.g., `private-sg`) and select your VPC.
        - Add an **inbound rule** to allow SSH (port 22) **only from the bastion host's security group** (select the bastion host security group as the source).
        - Add other inbound rules as needed for your application.
        - Click **Create security group**.

    34. **Launch an Amazon Linux Instance in the Private Subnet**
        - Go to the **EC2 Dashboard** and click **Launch Instance**.
        - Choose an **Amazon Linux 2 AMI**.
        - Select an **instance type** (e.g., t2.micro).
        - In **Network settings**, choose your VPC and select a **private subnet** (e.g., `Subnet-A2` or `Subnet-B2`).
        - Attach the `private-sg` security group.
        - For **Key pair**, select the key you generated earlier for private instances (e.g., `private-instance-key`).
        - Click **Launch Instance**.

    35. **Access the Private Instance via Bastion Host**
        - SSH into the bastion host as described previously.
        - From the bastion host, use the private key to SSH into the private instance:
          ```sh
          ssh -i ~/private-instance-key ec2-user@<private-instance-ip>
          ```
        -  ssh -i web-key.pem ec2-user@172.20.4.5
        - Command to access the private instance using the key copied to the bastion host.

    ## Steps to Deploy a Website in a Private Subnet Using a Template from tooplate.com

    36. **Connect to the Private Instance via Bastion Host**
        - SSH into the bastion host as described above.
        - From the bastion host, SSH into your private instance:
          ```sh
          ssh -i ~/private-instance-key ec2-user@<private-instance-ip>
          ```

    37. **Install Required Packages on the Private Instance**
        - Update the package list and install `httpd`, `wget`, and `unzip`:
          ```sh
          sudo yum update -y
          sudo yum install -y httpd wget unzip
          ```

    38. **Start and Enable the Apache Web Server**
        - Start the Apache service and enable it to start on boot:
          ```sh
          sudo systemctl start httpd
          sudo systemctl enable httpd
          ```

    39. **Download a Website Template from tooplate.com**
        - Visit [https://www.tooplate.com/](https://www.tooplate.com/) and choose a template.
        - Copy the download link for the template ZIP file.
        - Download the template to your instance (replace the URL below with your chosen template's link):
          ```sh
          wget https://www.tooplate.com/zip-templates/2136_kool_form_pack.zip
          ```

    40. **Unzip and Deploy the Template**
        - Unzip the downloaded file and copy its contents to the Apache web root:
          ```sh
          unzip 2136_kool_form_pack.zip
          sudo cp -r 2136_kool_form_pack/* /var/www/html/
          ```

        ## Steps to Create a Load Balancer, Target Group, and Security Group for Public Access

        41. **Create a Security Group for the Load Balancer**
            - In the VPC Dashboard, go to **Security Groups**.
            - Click **Create security group**.
            - Enter a name (e.g., `alb-sg`) and select your VPC.
            - Add an **inbound rule**:
              - Type: **HTTP**
              - Protocol: **TCP**
              - Port Range: **80**
              - Source: **0.0.0.0/0** (allows access from anywhere)
            - Add an **outbound rule** to allow all traffic (default).
            - Click **Create security group**.

        42. **Create a Target Group**
            - In the EC2 Dashboard, click **Target Groups** in the left sidebar.
            - Click **Create target group**.
            - Choose **Instances** as the target type.
            - Enter a name (e.g., `web-target-group`).
            - Select your VPC.
            - For **Protocol**, choose **HTTP** and **Port 80**.
            - Click **Next**.
            - Register your private instances as targets.
            - Click **Create target group**.

        43. **Create an Application Load Balancer**
            - In the EC2 Dashboard, click **Load Balancers** in the left sidebar.
            - Click **Create Load Balancer** > **Application Load Balancer**.
            - Enter a name (e.g., `web-alb`).
            - Scheme: **Internet-facing**.
            - IP address type: **IPv4**.
            - Select at least two public subnets (e.g., `Subnet-A1` and `Subnet-B1`).
            - Under **Security Groups**, select the `alb-sg` security group created earlier.
            - Under **Listeners and routing**, ensure a listener is set for **HTTP: 80** and forward to your target group (`web-target-group`).
            - Click **Create load balancer**.

        44. **Configure Inbound Rule for Private Instance Security Group**
            - In the VPC Dashboard, go to **Security Groups**.
            - Select the security group attached to your private Amazon Linux instance (e.g., `private-sg`).
            - Click **Edit inbound rules**.
            - Add a new rule:
              - **Type:** Custom TCP
              - **Port Range:** 80 (or your application's port)
              - **Source:** Select **Custom** and enter the security group ID of your load balancer (e.g., `sg-xxxxxxxx`).
            - This allows only the load balancer to access your private instance on the specified port.
            - Click **Save rules**.

        ## Steps to Create a VPC Peering Connection and Update Route Tables

        45. **Create a VPC Peering Connection**
            - In the VPC Dashboard, click **Peering Connections** in the left sidebar.
            - Click **Create peering connection**.
            - Enter a name (e.g., `vpc-peering-connection`).
            - For **VPC (Requester)**, select your current VPC.
            - For **VPC (Accepter)**, select the other VPC in your account (e.g., with CIDR `172.22.0.0/16`).
            - Click **Create peering connection**.

        46. **Accept the Peering Connection**
            - After creation, select the new peering connection in the list.
            - Click **Actions** > **Accept request**.
            - Confirm to accept the peering connection.

        47. **Update Route Tables to Enable Communication**
            - Go to **Route Tables** in the VPC Dashboard.
            - Select the route table(s) for your VPC.
            - Go to the **Routes** tab and click **Edit routes**.
            - Click **Add route**.
              - For **Destination**, enter `172.22.0.0/16`.
              - For **Target**, select the VPC peering connection you just created.
            - Click **Save changes**.
            - Repeat these steps for the route table(s) in the other VPC, adding a route to your VPC's CIDR block (e.g., `172.20.0.0/16`) with the same peering connection as the target.

        48. **(Optional) Update Security Groups**
            - Ensure that security groups in both VPCs allow traffic from the other VPC's CIDR block as needed for your use case.
            - SSH and Source have 172.22.0.0/16
            - For example, in the security group of your private instance, you might add an inbound rule to allow SSH from `
            - After completing these steps, your VPCs should be able to communicate with each other over the peering connection.