FOR CENTOS ---------------------------------------------------------------
1. Create Directory named templates , then create ntp server in Directory.
2. Go to Centos as root user search for chrony.conf , by using cat /etc/chrony.conf
3. copy all content from that file and then ,
4. Paste into templates folder in a file using vim templates/ntpconf_centos.

FOR UBUNTU ---------------------------------------------------------------
1. Create Directory named templates , then create ntp server in Directory.
2. Go to Centos as root user search for chrony.conf , by using cat /etc/ntpsec/ntp.conf
3. copy all content from that file and then ,
4. Paste into templates folder in a file using vim templates/ntpconf_ubuntu.

Then do Deploy of that ntp server using template module for proper info go yaml file