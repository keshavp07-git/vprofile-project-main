```markdown
## Creating a Docker Volume for MySQL 5.7

To persist MySQL data using a Docker volume, follow these steps:

1. **Create a Directory for Docker volume: Mount Bind Method**
    ```sh
    mkdir mysqldata
    ```

2. **Run the MySQL 5.7 container with the volume and port mapping (one line):**
    ```sh
    docker run -d --name vprodb -e MYSQL_ROOT_PASSWORD=secretpass -v /home/ubuntu/mysqldata:/var/lib/mysql -p 3030:3306 mysql:5.7
    ```

    - `-v /home/ubuntu/mysqldata:/var/lib/mysql` mounts the named Docker volume `mysqldata` to the MySQL data directory inside the container, ensuring data persists even if the container is removed.
    - `-p 3030:3306` maps the MySQL port from the container to the host, allowing you to connect to MySQL from outside the container.

This method used for development and testing purposes, but it is not recommended for production environments due to potential data loss if the host directory is deleted or modified and it is not portable across different environments also used for uploading code and files to the container.
```
3. **Log into the container:**
    ```sh
    docker exec -it vprodb /bin/bash
    ```
    ```sh
    cd /var/lib/mysql
    ```
    ```sh
    ls
    ```
Example output:
    ```
    All_MySQL_Files as showing in the connected Volume
    ```

4. **Create a Docker Volume (Recommended Method):**
        ```sh
        docker volume create mysqldata
        ```

5. **Run the MySQL 5.7 container using the named Docker volume:**
        ```sh
        docker run -d --name vprodb -e MYSQL_ROOT_PASSWORD=secretpass -v mysqldata:/var/lib/mysql -p 3030:3306 mysql:5.7
        ```

        - `-v mysqldata:/var/lib/mysql` attaches the named Docker volume `mysqldata` to the MySQL data directory inside the container.

    This method is preferred for portability and easier volume management, especially in production environments and data is not lost if the container is removed and can be reused across different containers.
    
6. **Verify the Docker Volume and MySQL Files:**
        ```sh
        sudo ls /var/lib/docker/volumes/mysqldata/_data
        ```
    This command lists the files stored in the `mysqldata` Docker volume, confirming that MySQL data is being persisted as expected.

7. **Connect to MySQL:**
    You can connect to the MySQL server using a MySQL client or command line:
    ```sh
    mysql -h 172.17.0.2 -u root -psecretpass
    ```
