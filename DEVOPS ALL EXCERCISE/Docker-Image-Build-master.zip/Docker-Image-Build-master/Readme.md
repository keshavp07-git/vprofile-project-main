# Preparing Nano Folio Template for Docker Image Build

This guide documents the steps to download, extract, package, and clean up the Nano Folio template for use in a Docker image build.

## Steps

1. **Create directories:**
    ```sh
    mkdir -p images/nano
    cd images/nano
    ```

2. **Download the template:**
    ```sh
    wget https://www.tooplate.com/zip-templates/2122_nano_folio.zip
    ```

3. **Extract the template:**
    ```sh
    unzip 2122_nano_folio.zip
    ```

4. **Package the contents into a tar.gz archive:**
    ```sh
    cd 2122_nano_folio
    tar czvf ../nano.tar.gz *
    cd ..
    ```

5. **Clean up unnecessary files:**
    ```sh
    rm -rf 2122_nano_folio 2122_nano_folio.zip
    ```

6. **Result:**
    - `nano.tar.gz` is ready for use in your Docker image build.

## Build the Docker Image

To build the Docker image using your prepared archive, run:

```sh
docker build -t nanoimg:v1 .
```
Build Artifact: `nano.tar.gz` and Dockerfile in the current directory. Then used above command to build the Docker image.
## Next Steps
```sh
docker run -d --name web -p 9080:80 nanoimg:v1
```
Use this command to run the Docker container in detached mode, mapping port 9080 on your host to port 80 in the container.
Check using instance Public IP address in your browser to see the Nano Folio template in action with the given port 9080.

You can now use `nano.tar.gz` in your Dockerfile to copy and extract the template as needed.

## Push Docker Image to Docker Hub

Follow these steps to connect your Docker Hub account and push your image:

1. **Login to Docker Hub:**
    ```sh
    docker login
    ```
    Enter your Docker Hub username and password when prompted.

2. **Tag your image for Docker Hub:**
    ```sh
    docker tag nanoimg:v1 <your-dockerhub-username>/nanoimg:v1
    ```
    Replace `<your-dockerhub-username>` with your actual Docker Hub username.

3. **Push the image to Docker Hub:**
    ```sh
    docker push <your-dockerhub-username>/nanoimg:v1
    ```

Your image will now be available in your Docker Hub repository.