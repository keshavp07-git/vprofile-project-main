# AWS Elastic Beanstalk Setup Guide

## 1. Create a Key Pair for Beanstalk
- Go to **EC2 Console** > **Key Pairs**.
- Click **Create key pair**.
- Name your key (e.g., `beanstalk-key`).
- Download and save the `.pem` file securely.

## 2. Create an Elastic Beanstalk Application
- Open **Elastic Beanstalk Console**.
- Click **Create Application**.
- Enter your application name (e.g., `MyApp`).

## 3. Configure Environment
- Choose **Web server environment**.
- Platform: **Tomcat**.
- Environment type: **Load balanced**.
- Number of instances: **2**.

## 4. Security Group (SG)
- Use the **default security group** or create a new one as needed.
- Ensure your environment is assigned a **unique DNS name** (Elastic Beanstalk provides this automatically, but you can customize it if needed).
- Enable **public IP assignment** for EC2 instances by selecting the option in the environment's network settings.
- In the **network configuration**, include **all available subnets** (public and private) to ensure high availability across multiple Availability Zones.

## 5. IAM Roles
- Assign the **AWS Elastic Beanstalk service role** (e.g., `aws-elasticbeanstalk-service-role`).
- Create an **EC2Instance Profile** with:
    - **Full access** to required AWS services.
    - **Web tier** permissions.
    - **SNS publish** permissions for notifications.
    - **custom platform for EC2 Role**
- Attach the role to your environment.

## 6. Load Balancer Settings
- Set **Minimum number of instances** to **2**.
- Set **Maximum number of instances** to **4**.
- Under **Load Balancer** configuration:
    - Enable **listeners** (e.g., HTTP:80, HTTPS:443 if needed).
    - Enable **stickiness** (session affinity) for the load balancer to maintain user sessions.
- Save and apply the configuration changes.

## 7. Create an RDS Database

- In the **AWS Management Console**, go to **RDS** > **Databases**.
- Click **Create database**.
- Select **Standard Create**.
- Engine: **MySQL**.
- Templates: Choose **Free tier** or **Production** as needed.
- Settings:
    - **DB instance identifier**: e.g., `vprofile-db`
    - **Master username**: `admin`
    - **Master password**: Select **Auto generate a password** (copy and save the generated password securely).
    - **DB name**: `accounts`
- Configure instance size, storage, and connectivity as required.
- Ensure the database is in the same VPC as your Elastic Beanstalk environment.
- Set security group rules to allow access from your application instances.
- Click **Create database** to launch the RDS instance.
- Save the **endpoint**, **username**, and **password** for application configuration.

## 8. Install MariaDB Client on Beanstalk Instances

- After connecting the security group of your Beanstalk environment with the MySQL (RDS) security group, access your Beanstalk EC2 instances via SSH using the key pair you created earlier.
- Once connected, update the package list and install the MariaDB client (choose the appropriate version for your instance architecture, x86 or x64):

    ```bash
    # For Amazon Linux 2
    sudo yum update -y
    sudo yum install -y mariadb1105
    ```

- Alternatively, for Ubuntu-based instances:

    ```bash
    sudo apt-get update
    sudo apt-get install -y mariadb-client
    ```

- After installation, connect to your RDS MySQL database using the following command (replace `<endpoint>`, `<password>`, and other placeholders with your actual values):

    ```bash
    mysql -h <RDS-endpoint> -u admin -p
    # Enter the auto-generated password when prompted
    # Switch to the 'accounts' database:
    USE accounts;
    ```

- You can now interact with your RDS database from the Beanstalk instance.

## 9. Download and Restore Database Structure

- Download the `db_backup.sql` file to your Beanstalk instance using `wget`:

    ```bash
    wget https://raw.githubusercontent.com/hkhcoder/vprofile-project/refs/heads/aws-ci/src/main/resources/db_backup.sql
    ```

- Import the database structure into the `accounts` database:

    ```bash
    mysql -h <RDS-endpoint> -u admin -p accounts < db_backup.sql
    ```

- Replace `<RDS-endpoint>` with your actual RDS endpoint. Enter the password when prompted.
- This will create the necessary tables and structure in your `accounts` database.
- Now your Elastic Beanstalk environment is set up with a connected RDS database.

## 10. Set Up Bitbucket Repository

- Go to [Bitbucket](https://bitbucket.org/).
- Click **Log in** and select **Continue with Google**. Complete the authentication process.
- Once logged in, click your profile icon and select **Create workspace**.
    - Enter a **unique workspace name** (e.g., `my-vprofile-workspace`).
    - Set the workspace ID (it must be unique).
    - Click **Create**.
- Inside your new workspace, click **Create repository**.
    - Enter a **repository name** (e.g., `vprofile-app`).
    - Set **Access level** to **Private**.
    - Uncheck **Include a README?** and **Include .gitignore?** so the repository is empty.
    - Click **Create repository**.
- Your empty private repository is now ready for use.

## 11. Generate SSH Key Pair Using Git Bash

- Open **Git Bash** on your local machine.
- Navigate to your `.ssh` directory:

    ```bash
    cd ~/.ssh
    ```

- Generate a new SSH key pair named `keys`:

    ```bash
    ssh-keygen
    ```

- When prompted, you can set a passphrase or leave it empty for no passphrase.
- This will create two files:
    - `keys` (private key)
    - `keys.pub` (public key)
- Keep your private key secure and never share it. Use the public key (`keys.pub`) for authentication with services like Bitbucket.
- Copy the contents of the public key to your clipboard:

    ```bash
    cat keys.pub
    ```
- Log in to your Bitbucket account, go to **Personal Bitbucket settings** > **SSH keys**, and click **Add key**.
- Paste the contents of your public key into the key field and give it a label (e.g., `My Laptop Key`).
- In same folder, create a file named `config` to simplify SSH access:

    ```bash
    touch config
    ```
- Open the `config` file in a text editor and add the following lines:

    ```
        # bitbucket.org    
        Host bitbucket.org
         PreferredAuthentications publickey
         IdentityFile ~/.ssh/keys
    ```
- Save the `config` file. This configuration allows you to use the SSH key without specifying it each time you connect to Bitbucket.
- Test your SSH connection to Bitbucket:

    ```bash
    ssh -T git@bitbucket.org
    ```

    ## 12. Clone the Bitbucket Repository Using SSH

    - In your Bitbucket repository, click the **Clone** button and select **SSH** to copy the SSH URL (e.g., `git@bitbucket.org:my-vprofile-workspace/vprofile-app.git`).
    - Open **Git Bash** or your terminal and navigate to the directory where you want to clone the repository.
    - Run the following command to clone the empty repository:

        ```bash
        git clone git@bitbucket.org:my-vprofile-workspace/vprofile-app.git
        ```

    - If your SSH key is set up correctly, the repository will be cloned without any authentication errors.
    - You can now start adding files and pushing changes to your Bitbucket repository using SSH.
    ## 13. Migrate GitHub Repository to Bitbucket (with Full History)

    To migrate your existing GitHub repository (e.g., `https://github.com/hkhcoder/vprofile-project.git`) to Bitbucket while preserving the full commit history, follow these steps:

    1. **Clone the Original GitHub Repository**

        ```bash
        git clone https://github.com/hkhcoder/vprofile-project.git
        cd vprofile-project
        ```

        - This creates a local copy of the GitHub repository.

    2. **List All Branches**

        ```bash
        git branch -a
        ```

        - Shows all local and remote branches.

    3. **Checkout the Desired Branch**

        ```bash
        git checkout branch-name
        ```

        - Replace `branch-name` with the branch you want to work on (e.g., `main` or `master` , `aws-c`).

    4. **Fetch All Tags**

        ```bash
        git fetch --tags
        ```

        - Downloads all tags from the remote repository.

    5. **Remove the Old Remote Origin**

        ```bash
        git remote rm origin
        ```

        - Removes the link to the original GitHub repository.

    6. **Add the New Bitbucket Remote**

        ```bash
        git remote add origin git@bitbucket.org:my-vprofile-workspace/vprofile-app.git
        ```

        - Replace the SSH URL with your Bitbucket repository's SSH address.

    7. **Push All Branches to Bitbucket**

        ```bash
        git push origin --all
        ```

        - Pushes all branches to the new Bitbucket repository.

    8. **Push All Tags to Bitbucket**

        ```bash
        git push --tags
        ```

        - Pushes all tags to Bitbucket.

    **Summary of Commands:**

    - `git clone <url>`: Clones the original repository.
    - `git branch -a`: Lists all branches.
    - `git checkout <branch>`: Switches to the specified branch.
    - `git fetch --tags`: Fetches all tags.
    - `git remote rm origin`: Removes the old remote.
    - `git remote add origin <new-url>`: Adds the new Bitbucket remote.
    - `git push origin --all`: Pushes all branches.
    - `git push --tags`: Pushes all tags.
    - `cat .git/config`: Displays the current Git configuration, including remotes.

    After these steps, your project (including all branches and tags) will be fully migrated from GitHub to Bitbucket.

    ## 14. Create an S3 Bucket to Store Build Artifacts

    To store your build artifacts (such as JAR, WAR, or ZIP files) for deployment or CI/CD, create an S3 bucket:

    1. **Go to the S3 Console**
        - Open the [AWS S3 Console](https://s3.console.aws.amazon.com/s3/).

    2. **Create a New Bucket**
        - Click **Create bucket**.
        - Enter a unique **Bucket name** (e.g., `vprofile-build-artifacts`).
        - Select the appropriate **AWS Region** (ideally the same as your Beanstalk environment).
        - Leave other settings as default or adjust as needed (e.g., enable versioning for artifact history).

    3. **Configure Bucket Permissions**
        - Uncheck **Block all public access** (recommended to keep checked for security).
        - Ensure only necessary IAM users/roles have access to this bucket.
        - Click **Create bucket**.


        ## 15. Set Up AWS CodeBuild with Bitbucket Integration

        To automate your build process using AWS CodeBuild and Bitbucket as the source, follow these steps:

        ### 1. Attach Bitbucket Account to AWS CodeBuild

        - Go to the **AWS CodeBuild Console**.
        - Click **Create build project**.
        - Under **Source provider**, select **Bitbucket**.
        - Choose **Connect using Bitbucket app** (recommended).
        - Click **Connect to Bitbucket** and follow the prompts to authorize AWS CodeBuild with your Bitbucket account.
        - Select the repository and branch (e.g., `aws-ci`) you want to use as the source.

        ### 2. Configure Environment

        - **Environment image:** Choose **Managed image**.
        - **Operating system:** Select **Ubuntu**.
        - **Runtime:** Standard.
        - **Image:** Choose the latest available standard image (e.g., `aws/codebuild/standard:7.0`).
        - **Service role:** Create or select an existing role with necessary permissions.

        ### 3. Add Buildspec

        - In the **Buildspec** section, choose **Insert build commands** and switch to the editor.
        - Copy and paste the following pipeline commands into the editor:

 ```yaml

    version: 0.2

phases:
  install:
    runtime-versions:
      java: corretto17
    commands:
      - apt-get update
      - apt-get install -y jq maven
  pre_build:
    commands:
      - sed -i 's/jdbc.password=admin123/jdbc.password=hV0urxRVXVtAEKczVq8Z/' src/main/resources/application.properties
      - sed -i 's/jdbc.username=admin/jdbc.username=admin/' src/main/resources/application.properties
      - sed -i 's/db01:3306/vproddb.cc3oewmqc2gg.us-east-1.rds.amazonaws.com:3306/' src/main/resources/application.properties
  build:
    commands:
      - mvn install
  post_build:
    commands:
      - mvn package

artifacts:
  files:
    - '**/*'
  base-directory: 'target/vprofile-v2'

```


### 4. Complete Project Setup

## 16. Set Up AWS CodePipeline for vProfile App

    To automate the deployment of your vProfile application using AWS CodePipeline, follow these steps:

1. **Open AWS CodePipeline Console**
        - Go to the [AWS CodePipeline Console](https://console.aws.amazon.com/codepipeline/).

    2. **Create a New Pipeline**
        - Click **Create pipeline**.
        - Enter a **Pipeline name** (e.g., `vprofile-ci-cd-pipeline`).
        - Choose a new or existing **Service role** with permissions for CodePipeline, CodeBuild, S3, and Elastic Beanstalk.
        - Click **Next**.

    3. **Add Source Stage**
        - **Source provider:** Select **Bitbucket**.
        - **Repository:** Choose your Bitbucket repository (e.g., `vprofile-app`).
        - **Branch:** Select the branch to build from (e.g., `aws-ci`).
        - **Change detection options:** Use default settings.
        - Click **Next**.

    4. **Add Build Stage**
        - **Build provider:** Select **AWS CodeBuild**.
        - **Region:** Choose your region.
        - **Project name:** Select the CodeBuild project you created earlier.
        - Click **Next**.

    5. **Add Deploy Stage**
        - **Deploy provider:** Select **AWS Elastic Beanstalk**.
        - **Region:** Choose your region.
        - **Application name:** Select your Elastic Beanstalk application (e.g., `MyApp`).
        - **Environment name:** Select the target environment.
        - **Input artifact:** Use the output artifact from the build stage (e.g., `BuildArtifact`).
        - Click **Next**.

    6. **Review and Create Pipeline**
        - Review all settings.
        - Click **Create pipeline**.

    Your pipeline will now automatically trigger on changes to your Bitbucket repository, build the application using CodeBuild, store artifacts in S3, and deploy to Elastic Beanstalk.

    ## 17. Update IAM Role for CodePipeline

    To grant your CodePipeline the necessary permissions for Elastic Beanstalk deployments, update the `AWSCodePipelineServiceRole-us-east-1-vpro` IAM role:

    1. **Go to the IAM Console**
        - Open the [AWS IAM Console](https://console.aws.amazon.com/iam/).

    2. **Find the Role**
        - In the left sidebar, click **Roles**.
        - Search for `AWSCodePipelineServiceRole-us-east-1-vpro` and select it.

    3. **Attach Elastic Beanstalk Full Access Policy**
        - Click **Add permissions** > **Attach policies**.
        - Search for `AWSElasticBeanstalkFullAccess`.
        - Check the box next to the policy and click **Next**.
        - Review and click **Add permissions**.

    4. **Save and Confirm**
        - The role now has full access to Elastic Beanstalk.
        - Your CodePipeline can deploy to Elastic Beanstalk without permission issues.

    **Note:** Always follow the principle of least privilege and only grant full access if required for your use case.

