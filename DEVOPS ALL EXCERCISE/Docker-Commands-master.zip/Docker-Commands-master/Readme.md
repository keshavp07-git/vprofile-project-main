# Docker Commands

A quick reference for commonly used Docker commands.

## Common Docker Arguments Explained
Here are some common Docker command arguments explained in simple terms:

- **-d**: Run the container in the background (detached mode).
- **-p <host_port>:<container_port>**: Map a port on your computer (host) to a port in the container.
- **-it**: Run the container in interactive mode with a terminal, so you can type commands inside it.
- **--name <name>**: Give your container a custom name.
- **-t <image_name>**: Tag the image with a name (used when building images).
- **-a**: Show all containers, including those that are stopped.
- **--rm**: Automatically remove the container when it stops running.
- **ps**: List running containers.
- **ps -a**: List all containers, including those that are stopped.
- **-P**: Publish all exposed ports to random ports on the host.
- **logs**: View the logs of a container.
- **inspect**: Display detailed information about containers, images, volumes, or networks.
- **exec**: Execute a command inside a running container.
- **rmi**: Remove an image.
- **rm**: Remove a container.
- **pull**: Download an image from a Docker registry (like Docker Hub).
- **-e**: Set environment variables in the container.
    

These arguments help you control how Docker containers and images behave.

---

## Container Management

- **List running containers**
    ```sh
    docker ps
    ```
- **List all containers (including stopped)**
    ```sh
    docker ps -a
    ```
- **Start a container**
    ```sh
    docker start <container_id>
    # Example:
    docker start 4e5f6a7b8c9d
    ```
- **Stop a container**
    ```sh
    docker stop <container_id>
    # Example:
    docker stop 4e5f6a7b8c9d
    ```
- **Remove a container**
    ```sh
    docker rm <container_id>
    # Example:
    docker rm 4e5f6a7b8c9d
    ```

## Image Management

- **List images**
    ```sh
    docker images
    ```
- **Pull an image**
    ```sh
    docker pull <image_name>
    # Example:
    docker pull nginx:latest
    ```
- **Remove an image**
    ```sh
    docker rmi <image_id>
    # Example:
    docker rmi 7e7c7f7e7c7f
    ```

## Building and Running

- **Build an image from a Dockerfile**
    ```sh
    docker build -t <image_name> .
    # Example:
    docker build -t myapp:latest .
    ```
- **Run a container**
    ```sh
    docker run -d -p <host_port>:<container_port> <image_name>
    # Example:
    docker run -d -p 8080:80 nginx:latest
    docker run -P nginx
    docker run --name myapp -d -p 7090:80 nginx:latest
    # --name myapp gives the container a custom name
    # -P publishes all exposed ports to random ports on the host
    # Not using -d will run the container in the foreground and show logs in the terminal cant escape
    ```

## Other Useful Commands

- **View container logs**
    ```sh
    docker logs <container_id>
    # Example:
    docker logs 4e5f6a7b8c9d
    ```
- **Inspect a container or image**
    ```sh
    docker inspect <container_id or image_name>
    # Example:
    docker inspect 4e5f6a7b8c9d
    docker inspect nginx:latest
    # Shows detailed information in JSON format.
    ```
- **Execute a command inside a running container**
    ```sh
    docker exec -it <container_id> <command>
    # Example:
    docker exec -it 4e5f6a7b8c9d /bin/bash
    # This opens a bash shell inside the container and allows you to run commands interactively.
    ```
- **Evironment Variables**
      ```sh
      docker run -d -P -e MYSQL_ROOT_PASSWORD=mypass mysql:5.7
      ```
    # This command runs a MySQL 5.7 container in detached mode, publishes all exposed ports to random host ports, and sets the `MYSQL_ROOT_PASSWORD` environment variable to `mypass`.

---

**Example placeholders:**
- `<container_id>`: `4e5f6a7b8c9d`
- `<image_name>`: `nginx:latest` or `myapp:latest`
- `<image_id>`: `7e7c7f7e7c7f`

*Replace placeholders with actual values as shown in the examples above.*