#!/bin/bash

set -e

# Update package index
echo "[+] Updating apt cache..."
sudo apt update -y

# Install required packages
echo "[+] Installing prerequisites..."
sudo apt install -y \
    ca-certificates \
    curl \
    gnupg \
    lsb-release \
    apt-transport-https \
    software-properties-common

# Add Docker’s official GPG key
echo "[+] Adding Docker GPG key..."
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
  sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Add Docker repository
echo "[+] Adding Docker repository..."
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Update apt index with Docker repo
echo "[+] Updating apt cache with Docker repo..."
sudo apt update -y

# Install Docker Engine, CLI, Containerd, and Compose plugin
echo "[+] Installing Docker Engine and Compose plugin..."
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Enable and start Docker service
echo "[+] Enabling and starting Docker..."
sudo systemctl enable docker
sudo systemctl start docker

# Add current user to docker group
echo "[+] Adding $USER to docker group..."
sudo usermod -aG docker $USER

# Show Docker and Compose versions
echo "[+] Docker version:"
docker --version

echo "[+] Docker Compose version (v2 via plugin):"
docker compose version

echo "✅ Docker and Docker Compose (v2) installed successfully!"
echo "ℹ️ Please log out and log back in to apply group changes."

