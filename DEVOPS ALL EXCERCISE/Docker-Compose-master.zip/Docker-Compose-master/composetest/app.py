import time  # Standard library for time-related functions (used for sleep)
import redis  # Redis client library for Python
from flask import Flask  # Flask web framework

app = Flask(__name__)  # Create a new Flask web application instance

# Create a Redis client connected to the 'redis' host on port 6379
cache = redis.Redis(host='redis', port=6379)

def get_hit_count():
    """
    Increment and return the 'hits' counter in Redis.
    Retries up to 5 times if a connection error occurs.
    """
    retries = 5  # Number of times to retry on connection error
    while True:
        try:
            # Try to increment the 'hits' key in Redis and return the new value
            return cache.incr('hits')
        except redis.exceptions.ConnectionError as exc:
            # If connection fails, retry up to 5 times, then raise the error
            if retries == 0:
                raise exc  # Raise the exception if out of retries
            retries -= 1  # Decrement the retry counter
            time.sleep(0.5)  # Wait for half a second before retrying

@app.route('/')  # Define the route for the root URL
def hello():
    """
    Handle requests to the root URL.
    Returns a greeting and the number of times the page has been visited.
    """
    count = get_hit_count()  # Get the current hit count from Redis
    return f'Hello World! I have been seen {count} times.\n'  # Return the response